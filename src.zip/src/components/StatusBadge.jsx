const STYLES = {
  requested: 'bg-amber-100 text-amber-800',
  confirmed: 'bg-sky-100 text-sky-800',
  in_progress: 'bg-indigo-100 text-indigo-800',
  completed: 'bg-emerald-100 text-emerald-800',
  cancelled: 'bg-slate-200 text-slate-600',
  no_show: 'bg-red-100 text-red-700',
  synced: 'bg-emerald-100 text-emerald-800',
  pending: 'bg-amber-100 text-amber-800',
  failed: 'bg-orange-100 text-orange-800',
  flagged: 'bg-red-100 text-red-700',
  scheduled: 'bg-slate-100 text-slate-600',
  sent: 'bg-sky-100 text-sky-800',
  delivered: 'bg-emerald-100 text-emerald-800',
};

export default function StatusBadge({ status, label }) {
  const text = label || String(status || '').replace('_', ' ');
  return (
    <span
      className={`chip ${STYLES[status] || 'bg-slate-100 text-slate-600'}`}
      data-testid={`status-badge-${status}`}
    >
      {text}
    </span>
  );
}
