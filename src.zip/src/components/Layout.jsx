import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext.jsx';
import { ROLE_LABELS } from '../utils/roles.js';
import DemoPanel from './DemoPanel.jsx';

const NAV = {
  patient: [['/patient', 'Overview', '⌂'], ['/patient/book', 'Book appointment', '+'], ['/patient/appointments', 'My appointments', '▦'], ['/patient/symptoms', 'Symptom form', '✚'], ['/patient/history', 'History & records', '▤']],
  doctor: [['/doctor', 'Schedule', '▦'], ['/doctor/consultations', 'Consultations', '♡']],
  staff: [['/staff/appointments', 'Appointments', '▦'], ['/staff/conflicts', 'Sync & conflict desk', '↻']],
  admin: [['/admin/users', 'Users', '♙']],
};

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const links = NAV[user?.role] || [];
  const current = links.find(([to]) => window.location.pathname === to || (to !== '/patient' && window.location.pathname.startsWith(to)))?.[1] || links[0]?.[1];
  return <div className="app-shell">
    <aside className="sidebar">
      <a href="#main-content" className="brand-lockup" aria-label="MediLynk home"><span className="brand-mark">✚</span><span>MediLynk</span></a>
      <div className="sidebar-caption">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">{links.map(([to, label, icon]) => <NavLink key={to} to={to} end={to.split('/').length === 2} data-testid={`nav-${to.replace(/\//g, '-').replace(/^-/, '')}`} className={({ isActive }) => `side-link ${isActive ? 'active' : ''}`}><span className="nav-icon" aria-hidden="true">{icon}</span><span>{label}</span></NavLink>)}</nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-help"><span className="help-icon">?</span><div><strong>Need help?</strong><small>Visit our support center</small></div></div>
      <div className="profile-card"><span className="avatar">{user?.name?.slice(0, 1)?.toUpperCase() || 'M'}</span><div className="profile-copy"><strong>{user?.name}</strong><small>{ROLE_LABELS[user?.role]}</small></div><button type="button" className="signout-button" aria-label="Sign out" data-testid="logout-button" onClick={() => { logout(); navigate('/login'); }}>↗</button></div>
    </aside>
    <div className="main-column"><header className="topbar"><div className="breadcrumb">Clinic <span>/</span> <strong>{current}</strong></div><div className="topbar-actions"><span className="availability"><i /> Clinic services available</span><span className="topbar-avatar">{user?.name?.slice(0, 1)?.toUpperCase() || 'M'}</span></div></header><main id="main-content" className="page-content"><Outlet /></main><footer className="page-footer">MediLynk · Secure care, wherever you are</footer></div>
    {user && <DemoPanel />}
  </div>;
}
