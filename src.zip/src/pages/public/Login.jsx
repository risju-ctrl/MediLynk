import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '../../auth/AuthContext.jsx';
import { loginSchema } from '../../utils/validators.js';
import { homeRoute } from '../../utils/roles.js';

const SEED_ACCOUNTS = [
  ['patient@1', 'maria@example.com', 'Patient123!'],
  ['patient@2', 'jose@example.com', 'Patient123!'],
  ['doctor', 'doctor@example.com', 'Doctor123!'],
  ['clinic staff', 'staff@example.com', 'Staff123!'],
  ['system admin', 'admin@example.com', 'Admin123!'],
];

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [apiError, setApiError] = useState('');
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(loginSchema), defaultValues: { email: '', password: '' } });

  const onSubmit = async (values) => {
    setApiError('');
    try {
      const session = await login(values.email, values.password);
      navigate(location.state?.from || homeRoute(session.user.role), { replace: true });
    } catch (error) {
      setApiError(error.message);
    }
  };

  return (
    <div className="mx-auto grid max-w-4xl gap-6 px-4 py-12 md:grid-cols-2">
      <div>
        <h1 className="text-2xl font-semibold text-brand-700">MediLynk</h1>
        <p className="mt-1 text-sm text-slate-600">
          Clinic Teleconsultation Booking and Reminder System — front-end prototype with mock data.
        </p>
        <div className="card mt-6">
          <h2 className="font-semibold text-slate-900">Sign in</h2>
          <form className="mt-4 space-y-3" onSubmit={handleSubmit(onSubmit)} noValidate>
            <div>
              <label className="label" htmlFor="email">
                Email address
              </label>
              <input id="email" className="input" data-testid="login-email" {...register('email')} />
              {errors.email && (
                <p className="error" data-testid="login-error-email">
                  {errors.email.message}
                </p>
              )}
            </div>
            <div>
              <label className="label" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                className="input"
                data-testid="login-password"
                {...register('password')}
              />
              {errors.password && (
                <p className="error" data-testid="login-error-password">
                  {errors.password.message}
                </p>
              )}
            </div>
            {apiError && (
              <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" data-testid="login-error">
                {apiError}
              </p>
            )}
            <button type="submit" className="btn-primary w-full" disabled={isSubmitting} data-testid="login-submit">
              {isSubmitting ? 'Signing in...' : 'Sign in'}
            </button>
          </form>
          <p className="mt-3 text-sm text-slate-600">
            New patient?{' '}
            <Link className="text-brand-700 underline" to="/register" data-testid="go-register">
              Create an account
            </Link>
          </p>
        </div>
      </div>

      <div className="card self-start">
        <h2 className="font-semibold text-slate-900">Seed accounts (synthetic)</h2>
        <p className="mt-1 text-xs text-slate-500">Click an account to fill the form.</p>
        <ul className="mt-3 space-y-2 text-sm">
          {SEED_ACCOUNTS.map(([label, email, password]) => (
            <li key={email}>
              <button
                type="button"
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-left hover:bg-slate-50"
                data-testid={`seed-${label.replace(/[^a-z0-9]/gi, '-')}`}
                onClick={() => {
                  setValue('email', email);
                  setValue('password', password);
                }}
              >
                <span className="font-medium">{label}</span>
                <span className="block text-xs text-slate-500">
                  {email} · {password}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
