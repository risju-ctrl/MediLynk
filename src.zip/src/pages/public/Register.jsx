import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '../../auth/AuthContext.jsx';
import { registrationSchema } from '../../utils/validators.js';

const FIELDS = [
  ['name', 'Full name', 'text', 'e.g. Maria Santos'],
  ['email', 'Email address', 'email', 'name@example.com'],
  ['phone', 'Mobile number', 'tel', '09XXXXXXXXX or +639XXXXXXXXX'],
  ['birthdate', 'Birthdate', 'date', ''],
  ['address', 'Home address', 'text', 'City, province'],
  ['password', 'Password', 'password', 'At least 8 characters with upper, lower and a number'],
  ['confirmPassword', 'Confirm password', 'password', ''],
];

export default function Register() {
  const { register: registerAccount } = useAuth();
  const navigate = useNavigate();
  const [apiError, setApiError] = useState('');
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(registrationSchema) });

  const onSubmit = async ({ confirmPassword, ...values }) => {
    setApiError('');
    try {
      await registerAccount(values);
      navigate('/patient', { replace: true });
    } catch (error) {
      setApiError(error.message);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-2xl font-semibold text-brand-700">Create a patient account</h1>
      <p className="mt-1 text-sm text-slate-600">
        Every field is validated. Empty, invalid and boundary values are rejected with a specific message (REQ-09).
      </p>

      <form className="card mt-6 grid gap-4 sm:grid-cols-2" onSubmit={handleSubmit(onSubmit)} noValidate>
        {FIELDS.map(([name, label, type, placeholder]) => (
          <div key={name} className={name === 'address' ? 'sm:col-span-2' : ''}>
            <label className="label" htmlFor={name}>
              {label}
            </label>
            <input
              id={name}
              type={type}
              placeholder={placeholder}
              className="input"
              data-testid={`register-${name}`}
              {...register(name)}
            />
            {errors[name] && (
              <p className="error" data-testid={`register-error-${name}`}>
                {errors[name].message}
              </p>
            )}
          </div>
        ))}

        {apiError && (
          <p className="sm:col-span-2 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" data-testid="register-error">
            {apiError}
          </p>
        )}

        <div className="sm:col-span-2 flex flex-wrap items-center gap-3">
          <button type="submit" className="btn-primary" disabled={isSubmitting} data-testid="register-submit">
            {isSubmitting ? 'Creating account...' : 'Create account'}
          </button>
          <Link to="/login" className="text-sm text-brand-700 underline" data-testid="go-login">
            Back to sign in
          </Link>
        </div>
      </form>
    </div>
  );
}
