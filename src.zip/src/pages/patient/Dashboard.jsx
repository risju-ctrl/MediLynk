import { Link } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext.jsx';
import { useAppointments } from '../../hooks/useAppointments.js';
import { ACTIVE_STATUSES, fmtDateTime, isExpired } from '../../utils/timeRules.js';
import AppointmentCard from '../../components/AppointmentCard.jsx';
import ReminderList from '../../components/ReminderList.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const { data, isPending, error } = useAppointments();

  const upcoming = (data?.appointments || []).filter(
    (appointment) => ACTIVE_STATUSES.includes(appointment.status) && !isExpired(appointment.start),
  );
  const next = upcoming[0];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">Hello, {user?.name?.split(' ')[0]}</h1>
        <p className="text-sm text-slate-600">Here is your next teleconsultation.</p>
      </div>

      {isPending && <p className="text-sm text-slate-500">Loading appointments...</p>}
      {error && <p className="text-sm text-red-600">{error.message}</p>}

      {next ? (
        <>
          <AppointmentCard appointment={next}>
            <Link to="/patient/appointments" className="btn-ghost" data-testid="dashboard-manage">
              Manage this appointment
            </Link>
          </AppointmentCard>
          <section className="card">
            <h2 className="font-semibold text-slate-900">Scheduled reminders</h2>
            <p className="mb-3 text-sm text-slate-500">
              Next appointment: {fmtDateTime(next.start)}. Reminders are simulated at 24 h and 1 h before (REQ-04).
            </p>
            <ReminderList appointmentId={next.id} />
          </section>
        </>
      ) : (
        <div className="card" data-testid="no-upcoming">
          <p className="text-sm text-slate-600">You have no upcoming consultations.</p>
          <Link to="/patient/book" className="btn-primary mt-3" data-testid="dashboard-book">
            Book a consultation
          </Link>
        </div>
      )}
    </div>
  );
}
