import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { bookAppointment, listDoctors } from '../../api/appointments.js';
import SlotPicker from '../../components/SlotPicker.jsx';
import ReminderList from '../../components/ReminderList.jsx';
import { fmtDateTime, toDateInput } from '../../utils/timeRules.js';

const tomorrow = () => toDateInput(new Date(Date.now() + 86400000));

export default function BookAppointment() {
  const queryClient = useQueryClient();
  const [doctorId, setDoctorId] = useState('');
  const [date, setDate] = useState(tomorrow());
  const [selected, setSelected] = useState(null);
  const [symptoms, setSymptoms] = useState('');
  const [message, setMessage] = useState('');
  const [booked, setBooked] = useState(null);
  const [raceResult, setRaceResult] = useState([]);

  const { data: doctors } = useQuery({ queryKey: ['doctors'], queryFn: listDoctors });

  const booking = useMutation({
    mutationFn: bookAppointment,
    onSuccess: (data) => {
      setBooked(data.appointment);
      setMessage('');
      setSelected(null);
      setSymptoms('');
      queryClient.invalidateQueries();
    },
    onError: (error) => {
      setMessage(error.message);
      setBooked(null);
      // A conflict means the slot list is stale, so refresh it (REQ-01).
      if (error.status === 409) queryClient.invalidateQueries({ queryKey: ['availability'] });
    },
  });

  const submit = (event) => {
    event.preventDefault();
    if (!selected) return setMessage('Choose an available slot first.');
    if (symptoms.trim().length < 10) return setMessage('Describe your symptoms in at least 10 characters.');
    return booking.mutate({ doctorId, start: selected.start, symptoms });
  };

  // Two requests fired at the same moment: the mock API allows exactly one to win.
  const simulateRace = async () => {
    if (!selected) return setMessage('Choose an available slot first.');
    setRaceResult([]);
    const payload = { doctorId, start: selected.start, symptoms: symptoms || 'Simultaneous booking test.' };
    const results = await Promise.allSettled([bookAppointment(payload), bookAppointment(payload)]);
    setRaceResult(
      results.map((result) =>
        result.status === 'fulfilled'
          ? `Accepted: ${result.value.appointment.id}`
          : `Rejected (${result.reason.status}): ${result.reason.message}`,
      ),
    );
    queryClient.invalidateQueries();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">Book a consultation</h1>
        <p className="text-sm text-slate-600">
          Slots inside the 10-minute buffer or in the past are blocked, and the mock API rejects them again (REQ-01, REQ-10).
        </p>
      </div>

      <form className="card space-y-4" onSubmit={submit} noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="doctor">
              Doctor
            </label>
            <select
              id="doctor"
              className="input"
              value={doctorId}
              onChange={(event) => {
                setDoctorId(event.target.value);
                setSelected(null);
                setBooked(null);
              }}
              data-testid="booking-doctor"
            >
              <option value="">Choose a doctor</option>
              {(doctors?.doctors || []).map((doctor) => (
                <option key={doctor.id} value={doctor.id}>
                  {doctor.name} — {doctor.specialty}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="date">
              Date
            </label>
            <input
              id="date"
              type="date"
              className="input"
              value={date}
              min={toDateInput()}
              onChange={(event) => {
                setDate(event.target.value);
                setSelected(null);
                setBooked(null);
              }}
              data-testid="booking-date"
            />
          </div>
        </div>

        <div>
          <p className="label">Available slots</p>
          <SlotPicker doctorId={doctorId} date={date} selected={selected?.start} onPick={setSelected} />
        </div>

        <div>
          <label className="label" htmlFor="symptoms">
            Symptoms / reason for consultation
          </label>
          <textarea
            id="symptoms"
            rows={3}
            className="input"
            value={symptoms}
            onChange={(event) => setSymptoms(event.target.value)}
            data-testid="booking-symptoms"
          />
        </div>

        {selected && (
          <p className="text-sm text-slate-600" data-testid="booking-selected">
            Selected: {fmtDateTime(selected.start)}
          </p>
        )}
        {message && (
          <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" data-testid="booking-error">
            {message}
          </p>
        )}

        <div className="flex flex-wrap gap-2">
          <button type="submit" className="btn-primary" disabled={booking.isPending} data-testid="booking-submit">
            {booking.isPending ? 'Booking...' : 'Confirm booking'}
          </button>
          <button
            type="button"
            className="btn-ghost"
            onClick={simulateRace}
            disabled={!selected}
            data-testid="simulate-simultaneous-booking"
            title="Sends two booking requests at the same time for the same slot"
          >
            Simulate two simultaneous requests
          </button>
        </div>

        {raceResult.length > 0 && (
          <ul className="space-y-1 text-sm" data-testid="race-result">
            {raceResult.map((line, index) => (
              <li key={index} className={line.startsWith('Accepted') ? 'text-emerald-700' : 'text-red-700'}>
                Request {index + 1} — {line}
              </li>
            ))}
          </ul>
        )}
      </form>

      {booked && (
        <section className="card" data-testid="booking-success">
          <h2 className="font-semibold text-slate-900">Appointment requested</h2>
          <p className="text-sm text-slate-600">
            {booked.doctorName} on {fmtDateTime(booked.start)}. Status: {booked.status}.
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Calendar sync: {booked.syncStatus}. The doctor's calendar refreshes within 5 seconds (REQ-03).
          </p>
          <div className="mt-4">
            <ReminderList appointmentId={booked.id} />
          </div>
        </section>
      )}
    </div>
  );
}
