import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { cancelAppointment, rescheduleAppointment } from '../../api/appointments.js';
import { useAppointments } from '../../hooks/useAppointments.js';
import AppointmentCard from '../../components/AppointmentCard.jsx';
import ReminderList from '../../components/ReminderList.jsx';
import ReschedulePanel from '../../components/ReschedulePanel.jsx';

export default function MyAppointments() {
  const queryClient = useQueryClient();
  const { data, isPending, error } = useAppointments();
  const [openReminders, setOpenReminders] = useState(null);
  const [openReschedule, setOpenReschedule] = useState(null);
  const [actionError, setActionError] = useState('');

  const refresh = () => queryClient.invalidateQueries();

  const cancel = async (id) => {
    setActionError('');
    try {
      await cancelAppointment(id);
      refresh();
    } catch (err) {
      setActionError(err.message);
    }
  };

  const reschedule = async (id, start) => {
    await rescheduleAppointment(id, start);
    setOpenReschedule(null);
    refresh();
  };

  if (isPending) return <p className="text-sm text-slate-500">Loading appointments...</p>;
  if (error) return <p className="text-sm text-red-600">{error.message}</p>;

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-slate-900">My appointments</h1>
      <p className="text-sm text-slate-600">
        You only see your own appointments. Another patient's record returns a 403 from the mock API (REQ-02).
      </p>
      {actionError && (
        <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" data-testid="appointment-action-error">
          {actionError}
        </p>
      )}

      {data.appointments.length === 0 && <p className="text-sm text-slate-600">No appointments yet.</p>}

      {data.appointments.map((appointment) => {
        const canChange = ['requested', 'confirmed'].includes(appointment.status);
        return (
          <div key={appointment.id}>
            <AppointmentCard appointment={appointment}>
              {['confirmed', 'in_progress'].includes(appointment.status) && (
                <Link to={`/patient/room/${appointment.id}`} className="btn-primary" data-testid={`patient-room-${appointment.id}`}>
                  Join room
                </Link>
              )}
              <button
                type="button"
                className="btn-ghost"
                onClick={() => setOpenReminders(openReminders === appointment.id ? null : appointment.id)}
                data-testid={`toggle-reminders-${appointment.id}`}
              >
                {openReminders === appointment.id ? 'Hide reminders' : 'Show reminders'}
              </button>
              <button
                type="button"
                className="btn-ghost"
                disabled={!canChange}
                onClick={() => setOpenReschedule(openReschedule === appointment.id ? null : appointment.id)}
                data-testid={`toggle-reschedule-${appointment.id}`}
              >
                Reschedule
              </button>
              <button
                type="button"
                className="btn-danger"
                disabled={!canChange}
                onClick={() => cancel(appointment.id)}
                data-testid={`cancel-${appointment.id}`}
              >
                Cancel
              </button>
            </AppointmentCard>

            {openReminders === appointment.id && (
              <div className="card mt-2">
                <ReminderList appointmentId={appointment.id} />
              </div>
            )}
            {openReschedule === appointment.id && (
              <ReschedulePanel
                appointment={appointment}
                onDone={(start) => reschedule(appointment.id, start)}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
